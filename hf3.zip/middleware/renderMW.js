/**
 * A templatebe ertekek betoltese
 */