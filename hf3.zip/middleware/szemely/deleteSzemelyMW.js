/**
 *  Post: Ha az adott id-val letezik szemely, akkor a torles gomb megnyomasaval torli az adatokat.
 */