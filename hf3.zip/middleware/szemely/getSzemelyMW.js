/**
 * Get: Lekerdezi az adott id-val rendelkezo Szemely adatait.
 */