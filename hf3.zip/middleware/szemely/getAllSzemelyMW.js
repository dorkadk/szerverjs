/**
 * Get: Lekerdezi az osszes Szemely adatait.
 */