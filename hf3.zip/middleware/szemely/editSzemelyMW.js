/**
 *  Post: Ha az adott id-val letezik szemely, akkor a mentes gomb megnyomasaval modositja az adatokat.
 */