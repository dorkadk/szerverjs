/**
 * Post: Ha az adott id-val meg nem letezik kerekpar, akkor a letrehozas gomb megnyomasaval letrehozza az uj kerekpart.
 */