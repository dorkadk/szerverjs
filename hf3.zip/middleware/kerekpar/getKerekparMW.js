/**
 * Get: Lekerdezi az adott id-val rendelkezo Kerekpar adatait.
 */