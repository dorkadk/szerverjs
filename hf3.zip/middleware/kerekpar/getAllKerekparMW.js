/**
 * Get: Lekerdezi az osszes Kerekpar adatait.
 */