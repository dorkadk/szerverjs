/**
 *  Post: Ha az adott id-val letezik kerekpar, akkor a mentes gomb megnyomasaval modositja az adatokat.
 */