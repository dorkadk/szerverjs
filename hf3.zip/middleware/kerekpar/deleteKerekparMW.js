/**
 *  Post: Ha az adott id-val letezik kerekpar, akkor a torles gomb megnyomasaval torli az adatokat.
 */